#ifndef REPO_H
#define REPO_H
#include <string>

using namespace std;


class Repo
{
    public:
        Repo();
        virtual ~Repo();


        string readorders(int* a);

    protected:

    private:

};

#endif // REPO_H
