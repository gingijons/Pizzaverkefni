#ifndef SALARY_H
#define SALARY_H
#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

class Salary
{
    public:
        Salary(string name, string SSN, int sala, int month, int year);
        string getName();
        string getSSN();
        int getSala();
        int getMonth();
        int getYear();
        int sala;
        friend ostream& operator << (ostream& out, const Salary& salary);

    private:
        string name;
        string SSN;
        int month;
        int year;
};

#endif // SALARY_H
