#ifndef SALARYUI_H
#define SALARYUI_H
#include <stdio.h>
#include <iostream>
#include <string>
#include "Salary.h"
#include "SalaryService.h"
using namespace std;

class SalaryUI
{
public:
    void main_menu();
    Salary salary(string name, int SSN, int sala, int month, int year);

private:
    void validate_user_input(char input);
    SalaryService salary_service;
    Salary create_user();
    Salary view_user();
};

#endif // SALARYUI_H
