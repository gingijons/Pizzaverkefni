#ifndef SALARYREPO_H
#define SALARYREPO_H
#include <fstream>
#include "Salary.h"


class SalaryRepo
{
public:
    SalaryRepo();
    void add_salary(const Salary& salary);
    void view_salarySSN(const Salary& salary);
    void view_total(const Salary& salary);
    void view_highest(const Salary& salary);
    void add_sala(int& sala);


private:

};

#endif // SALARYREPO_H
