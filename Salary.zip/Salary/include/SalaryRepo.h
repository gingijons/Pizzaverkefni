#ifndef SALARYREPO_H
#define SALARYREPO_H
#include <fstream>
#include "Salary.h"


class SalaryRepo
{
public:
    SalaryRepo();
    void add_salary(const Salary& salary);
    void view_salary(const Salary& salary);


private:

};

#endif // SALARYREPO_H
