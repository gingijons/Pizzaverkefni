#ifndef SALARYSERVICE_H
#define SALARYSERVICE_H
#include <stdio.h>
#include "Salary.h"
#include "SalaryRepo.h"
using namespace std;


class SalaryService
{
public:
    SalaryService();
    void add_salary(const Salary& salary);
    void view_salarySSN(const Salary& salary);
    //void view_highest(const Salary& salary);
    void view_total(const Salary& salary);
    bool is_valid_salary(const Salary& salary);


private:
    SalaryRepo salary_repo;
};

#endif // SALARYSERVICE_H
