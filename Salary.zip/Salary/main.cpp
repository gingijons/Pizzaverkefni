#include <iostream>
#include "SalaryUI.h"
using namespace std;


int main()
{

    SalaryUI salary_ui;
    salary_ui.main_menu();

    return 0;
}
