#include "SalaryService.h"

SalaryService::SalaryService()
{

}

void SalaryService::add_salary(const Salary& salary)
{
    salary_repo.add_salary(salary);
    cout << salary << endl;
}

void SalaryService::view_salary(const Salary& salary)
{
    salary_repo.view_salary(salary);

}
