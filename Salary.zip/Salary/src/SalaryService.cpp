#include "SalaryService.h"

SalaryService::SalaryService()
{

}

void SalaryService::add_salary(const Salary& salary)
{
    salary_repo.add_salary(salary);
    cout << salary << endl;
}

void SalaryService::view_salarySSN(const Salary& salary)
{
    salary_repo.view_salarySSN(salary);
}

void SalaryService::view_total(const Salary& salary)
{
    salary_repo.view_total(salary);
}

/*void SalaryService::view_highest(const Salary& salary);
{
    salary_repo.view_highest(salary)
}*/
