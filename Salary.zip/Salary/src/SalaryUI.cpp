#include "SalaryUI.h"


void SalaryUI::main_menu()
{
    cout << "Hello employee" << endl;

    while(true)
    {
        cout << "Pick a number for the corresponding option" << endl;
        cout << "***************************************" << endl;
        cout << "1. Add a new employee salary" << endl;
        cout << "2. View employee salary (SSN)" << endl;
        cout << "3. View total salary for SSN" << endl;
        cout << "4. View the highest salary" << endl;
        cout << endl;
        char input;
        cin >> input;
        validate_user_input(input);
    }
}
void SalaryUI::validate_user_input(char input)
{
    if (input == '1')
    {
        salary_service.add_salary(create_user());
    }
    else if (input == '2')
    {
        cout << "viewing salary" << endl;
        salary_service.view_salary(view_user());
    }
    else
    {
        cout << "invalid input!" << endl;
    }
}

Salary SalaryUI::create_user()
{
    string name;
    string SSN;
    int sala;
    int month, year;
    cout << "Name: ";
    cin >> name;
    cout << "Social Security: ";
    cin >> SSN;
    cout << "Enter Salary: ";
    cin >> sala;
    cout << "What month? ";
    cin >> month;
    cout << "What year? ";
    cin >> year;

    Salary salary(name, SSN, sala, month, year);
    return salary;
}

Salary SalaryUI::view_user()
{

    string name;
    string SSN;
    int sala;
    int month, year;

   Salary salary(name, SSN, sala, month, year);
   return salary;
}

