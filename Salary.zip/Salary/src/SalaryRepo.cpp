#include "SalaryRepo.h"
#include <vector>
#include <cstdlib>

SalaryRepo::SalaryRepo()
{

}

void SalaryRepo::add_salary(const Salary& salary)
{
    ofstream fout;
    fout.open("salary.txt", ios::app);
    if(fout.is_open())
    {
        cout << salary << endl;
        fout << salary;
        fout.close();
    }
    else
    {
        /// throw error
    }
}

void SalaryRepo::add_sala(int& sala)
{
    ofstream fout;
    fout.open("just_salary.txt", ios::app);
    if(fout.is_open())
    {
        fout << endl;
        fout << sala;
        fout.close();
    }
}

void SalaryRepo::view_salarySSN(const Salary& salary)
{
    string str;
    string input;
    fstream fin;
    fin.open("salary.txt");
    if(fin.is_open())
    {
        while(!fin.eof())
        {
            cin >> input;
            while(getline(fin, str))
            {
                if(str.find(input) != string::npos)
                {
                    cout << str;
                }
            }
            cout << endl;
        }
        fin.close();
    }
}
void SalaryRepo::view_total(const Salary& salary)
{
    string str[1000];
    string b;
    string input;
    int a = 0;
    fstream fin;
    fstream obj;
    vector<int> location;
    obj.open("salary.txt");

    while(getline(obj, b))
    {
        a++;
    }

    obj.close();
    fin.open("salary.txt");

    if(fin.is_open())
    {
        cout << "SSN: ";
        cin >> input;
        for(int i = 0; i < a; i++)
        {
            getline(fin, str[i]);
            //cout << str[i] << endl;
            //cout << i;

            if(str[i].find(input) != string::npos)
            {
                location.push_back(i);
                //cout << i;
            }
        }
        //cout << str[location[0]] << endl;
    }

    //cout << location.size();

    fin.close();
    fstream bin;
    int total = 0;
    string string_sal[50];
    int sal[50];

    bin.open("just_salary.txt");
    for(unsigned int i = 0; i < a; i++)
    {
        getline(bin, string_sal[i]);
        sal[i] = atoi( string_sal[i].c_str());
    }


    for(int i = 0; i < location.size(); i++)
    {
        cout << sal[location[i]] << endl;
        total += sal[location[i]];
    }

    cout << "Total: " << total << endl;
    cout << endl;
}

void SalaryRepo::view_highest(const Salary& salary)
{

}
