#include "SalaryRepo.h"

SalaryRepo::SalaryRepo()
{

}

void SalaryRepo::add_salary(const Salary& salary)
{
    ofstream fout;
    fout.open("salary.txt", ios::app);
    if(fout.is_open())
    {
        fout << salary;
        fout.close();
    }
    else
    {
        /// throw error
    }
}
void SalaryRepo::view_salary(const Salary& salary)
{
    string str;
    fstream fin;
    fin.open("salary.txt");
    if(fin.is_open())
    {
        while(!fin.eof())
        {
            cout << "test " << endl;
            getline(fin, str);
            cout << str;
        }
        fin.close();
    }
    else
    {
        cout << "Closed" << endl;
    }
}
