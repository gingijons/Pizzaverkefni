#include "Salary.h"

Salary::Salary(string name, string SSN, int sala, int month, int year)
{
    this->name = name;
    this->SSN = SSN;
    this->sala = sala;
    this->month = month;
    this->year = year;
}

string Salary::getName()
{
    return this->name;
}
string Salary::getSSN()
{
    return this->SSN;
}
int Salary::getSala()
{
    return this->sala;
}
int Salary::getMonth()
{
    return this->month;
}
int Salary::getYear()
{
    return this->year;
}

ostream& operator << (ostream& out, const Salary& salary)
{
    out << salary.name << ", " << salary.SSN << ", " << salary.sala << ", " << salary.month << ", " << salary.year << endl;
    return out;
}


