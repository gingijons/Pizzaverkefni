#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int getpriceforsize(string size)
{
    int price;

    if(size == "lit")
    {
        price = 1499;
    }
    else if(size == "mid")
    {
        price = 1999;
    }
    else
    {
        price = 2999;
    }
    return price;
}

string getpizzasize()
{
    string size;
    do
    {
        cout << "Size (lit mid sto) ";
        cin >> size;
        if(size == "sto" || size == "lit" || size == "mid")
        {
            break;
        }
        else
        {
            cout << "invalid size" << endl;
        }
    }
    while(true);

    return size;

}

void gettoppings(vector<string> *top, int *j)
{
    cout << "topping: (ppp, bei, rjo, sve) ";
    int i = 0;
    *j = i;
    top->clear();

    do
    {
        string topping;
        cin >> topping;
        //topping == "ppp" || topping == "rjo" || topping == "sve" || topping == "bei"

        //str[i].find('\\')
        if(topping == "ppp" || topping == "rjo" || topping == "sve" || topping == "bei")
        {
            top->push_back(topping);
            *j+=1;
        }
        else
        {
            break;
        }

    }while(true);
}

int main()
{
    ifstream fin;
    ifstream bin;
    ofstream fout;
    int a = 0;
    int s = 0;
    int *j = &s;
    int price = 0;
    string b;
    string str[1000];
    char login;

    bin.open("pantanir.txt");

    while(getline(bin, b))
    {
        a++;
    }

    fin.open("pantanir.txt");


    for(int i = 0; i < a; i++)
    {
        getline(fin, str[i]);
        //cout << str[i] << endl;
    }
    bin.close();
    fin.close();

    fout.open("pantanir.txt");

    for(int i = 0; i < a; i++)
    {
        fout << str[i] << endl;
    }
    fout.close();

    cout << "(o = order, c = cashier)" << endl;
    cout << "login: ";
    cin >> login;


    if(login == 'o')
    {


        string size;
        vector<string> top;
        char cont;

        do
        {
        size = getpizzasize();

        gettoppings(&top, j);

        price = getpriceforsize(size);

        price += (*j*150);

        cout << "<" << a+1 << "> <" << size << "> <";

        for(unsigned int i = 0; i < top.size(); i++)
        {
            if(!top[i].empty())
            {
                if(i==top.size()-1)
                {
                    cout << top[i];
                }
                else
                {
                    cout << top[i] << " ";
                }

            }
            if(top[i].empty()==true)
            {
                break;
            }
        }

        cout << "> <" << price << ">" << endl;

        fout.open("pantanir.txt");

        for(int i = 0; i < a; i++)
        {
            fout << str[i] << endl;
        }

        fout << "<" << a+1 << "> <" << size << "> <";

            for(unsigned int i = 0; i < top.size(); i++)
        {
            if(!top[i].empty())
            {
                if(i==top.size()-1)
                {
                    fout << top[i];
                }
                else
                {
                    fout << top[i] << " ";
                }

            }
            if(top[i].empty()==true)
            {
                break;
            }
        }

        fout << "> <" << price << ">" << endl;
        a++;

        cout << "another order? (y/n): ";
        cin >> cont;

        } while(cont == 'y' || cont == 'Y');


        fout.close();
    }

    if(login == 'c')
    {
        int order_num;
        char paid;
        do
        {
            cout << "Enter order number: ";
            cin >> order_num;
            cout << endl;
            order_num -= 1;
            if(order_num > a)
            {
                cout << "There are only " << a << " orders" << endl;
            }
            else{break;}
        }while(true);

        cout << str[order_num];
        cout << endl;
        cout << endl;
        cout << "mark paid? (y/n): ";
        cin >> paid;
        cout << endl;

        fout.open("pantanir.txt");

        if(paid == 'y' || paid == 'Y')
        {
            if(!str[order_num].find("greidd"))
            {
                cout << "Already payed";
            }
            else
            {
                for(int i = 0; i < a; i++)
                {
                    if(i==order_num)
                    {
                        fout << str[order_num] << " <greidd>" << endl;
                    }
                    else
                    {
                        fout << str[i] << endl;
                    }
                }
                cout << str[order_num] << " <greidd>";
            }
        }
        fout.close();
    }


    return 0;
}
